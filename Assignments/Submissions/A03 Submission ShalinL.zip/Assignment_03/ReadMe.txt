7. Missile Fire
	(0.5) Physical Projectile, 3D Model (Possibly Cylinder, Add a better front-facing face)
	(0.5) Correct adaptaion of ray-sphere intersection to missile collision
		(2 rays, parralel to rocket, at an offset =  to missile width)

I am using the same control scheme as in class with several modifications.

	1. Press Left Control to toggle view
	2. Press Space to fire Laser
	3. Press Left Shift to brake.
		Recommend braking when making sharp turns
	
Laser will not destroy asteroid that are too close to the player. Try to hit them with the yellow, not the orange.