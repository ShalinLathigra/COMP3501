#pragma once
/*

Need:
	Entity
		- Position
		- 
		- Model*
				typedef struct model {
				    GLuint vbo; // OpenGL vertex buffer object
				    GLuint ebo; // OpenGL element buffer object
				    GLuint size; // Size of data to be drawn
				} Model;

*/

