1: CLEAR SCREENSPACE EFFECTS
2: Screen Wipe
3: Red Error
4: Getting Woozy

5: CLEAR PARTICLE EFFECTS
6: Fireworks Only
7: Flamethrower Only
8: Ring Explosion Only